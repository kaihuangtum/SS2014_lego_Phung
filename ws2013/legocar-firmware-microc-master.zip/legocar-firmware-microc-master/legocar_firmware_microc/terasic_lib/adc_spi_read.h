#ifndef ADC_SPI_READ_H_
#define ADC_SPI_READ_H_

alt_u16 ADC_Read(alt_u8 NextChannel);

#endif /*ADC_SPI_READ_H_*/
