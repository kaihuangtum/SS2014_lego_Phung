Readme - firmware for a legocar using MicroC/OS-II

This project was developed in the winter-semester 2013/14 at the
Technische Universität München at the faculty for computer science
at the chair for robotics.

The car is able to do different movements (driving straight, diagonal,
turning on the position, curves), and read acceleration data from the
sensor on the used DE0_Nano FPGA-board.

Developers involved:
Adhir Ghosh, Alibi Rakhmatulin, Markus Bauer, Antônio Colares, Raphael Dümig
